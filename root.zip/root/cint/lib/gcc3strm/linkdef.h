
#ifdef __MAKECINT__

#pragma link off class allocator<char>;
#pragma link off class allocator<wchar_t>;

#endif
