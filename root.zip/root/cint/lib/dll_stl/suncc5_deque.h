#ifndef G__SUNCC5_DEQUE_H
#define G__SUNCC5_DEQUE_H

#if (__SUNPRO_CC>=1280)
namespace __rwstd {
#ifdef _RWSTD_LOCALIZED_ERRORS
  const unsigned int _RWSTDExport rwse_OutOfRange = 0;
#else
  const char _RWSTDExportFunc(*) rwse_OutOfRange = 0;
#endif // _RWSTD_LOCALIZED_ERRORS
}
#endif

#endif
