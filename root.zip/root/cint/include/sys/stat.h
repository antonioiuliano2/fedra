/* POSIX dummy file */
