/**************************************************************************
* readfile.h
*
**************************************************************************/
#ifndef G__REGEXP_H
#define G__REGEXP_H


#ifndef G__REGEXPSL

#ifdef G__SHAREDLIB
#pragma include <RegE.dll>
#else
#include <RegE.C>
#endif

#endif

