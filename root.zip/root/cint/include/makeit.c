main() {
  system("makeit.bat");
}
