/****************************************************************
* fcntl.h
*****************************************************************/
#ifndef G__FCNTL_H
#define G__FCNTL_H

#pragma include_noerr <systypes.h>
#ifndef G__SYSTYPES_H
typedef unsigned short mode_t;
#endif

#endif
