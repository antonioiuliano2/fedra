/*****************************************************************************
* Common.h
*****************************************************************************/

#ifndef COMMON_H
#define COMMON_H


#ifndef bool
typedef char bool;
#endif

// enum BOOLVALUE { FALSE , TRUE };
const bool FALSE=0;
const bool TRUE=1;

#endif
