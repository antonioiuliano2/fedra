#ifndef G__STDDEF_H
#define G__STDDEF_H
typedef long ptrdiff_t;
typedef unsigned int size_t;
typedef unsigned int wchar_t;
#endif
