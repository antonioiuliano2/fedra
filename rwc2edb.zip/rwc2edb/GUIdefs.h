#ifndef _SYSAL_GUI_DEFINITIONS_
#define _SYSAL_GUI_DEFINITIONS_

typedef long HSySalHANDLE;
typedef long HSySalHICON;
typedef long HSySalHBITMAP;
typedef long HSySalHWND;

#endif